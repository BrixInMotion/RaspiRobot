/*
 * main.c
 *
 *  Created on: 2016 Jan 01 21:15:46
 *  Author: Kilian2
 */




#include <DAVE.h>                 //Declarations from DAVE Code Generation (includes SFR declaration)
#include <xmc_gpio.h>
#define XMC_DEBUG_ENABLE

 #define DATA_COUNT 256
 uint8_t data_buffer[DATA_COUNT], data_buffer_index;
#define I2C_DATA_BLOCK_SIZE	1
 unsigned char data_buffer_index;
  //INTERRUPT APP callback function

 //-----------------------------------
 //  I2C:
 //  SDA          Port P1.2
 //  SCL          Port P1.3
 //
 //  PWM out:
 //  PWM_LEFT_WHEEL   Port P2.0			// left wheel : 0 forward, 1 backward
 //  PWM_RIGHT_WHEEL   Port P2.1			// right wheel: 0 forward, 1 backward
 //  PWM_ELEVATOR   Port P0.3			// elevator   : 0 up, 1 down
 //
 //  GPIO
 //  Direction PWM 0	Port P0.0	// left wheel : 0 forward, 1 backward
 //  Direction PWM 1	Port P0.1	// right wheel: 0 forward, 1 backward
 //  Direction PWM 2	Port P0.2	// elevator   : 0 up, 1 down
 //-----------------------------------


  void rx_cb()
  { // this function expects either to reveive 2 bytes or 1 byte and a write request for 1 byte
	  unsigned char temp;

	  temp = I2C_SLAVE_GetReceivedByte(&I2C_SLAVE_0);
	  data_buffer_index++;

	  if(!I2C_SLAVE_IsRXFIFOEmpty(&I2C_SLAVE_0))
	  {
		  data_buffer[temp] = I2C_SLAVE_GetReceivedByte(&I2C_SLAVE_0);
		  data_buffer_index++;
	  }
	  else
		 while(1);  // should never arrive here because interrupt should be entered only when 2 bytes are in buffer

	  if(!I2C_SLAVE_IsRXFIFOEmpty(&I2C_SLAVE_0))
		  while(1);  // should never arrive here, we expect only 2 bytes, buffer must be empty

  }

  void tx_cb()
  {
//	  if(I2C_SLAVE_GetFlagStatus(&I2C_SLAVE_0, XMC_I2C_CH_STATUS_FLAG_SLAVE_READ_REQUESTED))
	  {
	    	   I2C_SLAVE_TransmitByte(&I2C_SLAVE_0,data_buffer[I2C_SLAVE_GetReceivedByte(&I2C_SLAVE_0)]);
	    	   I2C_SLAVE_ClearFlag(&I2C_SLAVE_0, XMC_I2C_CH_STATUS_FLAG_SLAVE_READ_REQUESTED);
	  }
  }


/**

 * @brief main() - Application entry point
 *
 * <b>Details of function</b><br>
 * This routine is the application entry point. It is invoked by the device startup code. It is responsible for
 * invoking the APP initialization dispatcher routine - DAVE_Init() and hosting the place-holder for user application
 * code.
 */

int main(void)
{
  DAVE_STATUS_t status;
  unsigned int count_i,count_i2;
  //I2C_SLAVE_STATUS_t i2c_status;
  //PWM_CCU4_STATUS_t pwm_status;

  status = DAVE_Init();           /* Initialization of DAVE APPs  */

  if(status == DAVE_STATUS_FAILURE)
  {
    /* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
    XMC_DEBUG("DAVE APPs initialization failed\n");

    while(1U){}
  }
  XMC_DEBUG("DAVE APPs initialization successfull\n");

/*  init_status = (I2C_SLAVE_STATUS_t)I2C_SLAVE_Init(&I2C_SLAVE_0);
  if(init_status != I2C_SLAVE_STATUS_SUCCESS)
	    while(1U){}
*/

  data_buffer_index = 0;
  /* Placeholder for user application code. The while loop below can be replaced with user application code. */

  for (count_i=0; count_i<256;count_i++) data_buffer[count_i] = 0xFF;  // fill with FF to make changes to 00 visible

  //Configure receive FIFO to generate event when FIFO is filled with n bytes
  I2C_SLAVE_SetRXFIFOTriggerLimit(&I2C_SLAVE_0, I2C_DATA_BLOCK_SIZE);



  XMC_GPIO_SetMode(P0_4, XMC_GPIO_MODE_OUTPUT_PUSH_PULL);
  PWM_CCU4_Start(&PWM_LEFT_WHEEL);
  while(1)
  {
	  for (count_i=0;count_i<10000;count_i=count_i+10)
	  {
		  PWM_CCU4_SetDutyCycle(&PWM_LEFT_WHEEL, count_i);
		  XMC_GPIO_SetOutputHigh  ( P0_4 );
		  for(count_i2=0;count_i2<5000;count_i2++);
		  XMC_GPIO_SetOutputLow  ( P0_4 );
	  }
	  for(count_i2=0;count_i2<50000;count_i2++);

	  for (count_i=10000;count_i!=0;count_i=count_i-10)
	  {
		  PWM_CCU4_SetDutyCycle(&PWM_LEFT_WHEEL, count_i);
		  for(count_i2=0;count_i2<5000;count_i2++);
	  }
	  PWM_CCU4_Stop(&PWM_LEFT_WHEEL);
	  for(count_i2=0;count_i2<50000;count_i2++);
  }

      while(1)
      {

      }

}
